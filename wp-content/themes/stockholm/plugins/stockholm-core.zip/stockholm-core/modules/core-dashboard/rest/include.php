<?php

include_once STOCKHOLM_CORE_ABS_PATH . '/modules/core-dashboard/rest/rest.php';