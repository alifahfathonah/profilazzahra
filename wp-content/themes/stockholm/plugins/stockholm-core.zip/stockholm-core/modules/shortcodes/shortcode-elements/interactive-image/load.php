<?php

include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/interactive-image/functions.php';
include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/interactive-image/interactive-image.php';