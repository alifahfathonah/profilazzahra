<div class="portfolio_shader"></div>
<div class="text_holder">
	<?php
	echo stockholm_qode_get_shortcode_template_part('templates/parts/title', 'portfolio-list', '', $params);
	echo stockholm_qode_get_shortcode_template_part('templates/parts/subtitle', 'portfolio-list', '', $params);
	echo stockholm_qode_get_shortcode_template_part('templates/parts/categories', 'portfolio-list', '', $params);
	?>
</div>
<?php echo stockholm_qode_get_shortcode_template_part('templates/parts/icons', 'portfolio-list', '', $params); ?>