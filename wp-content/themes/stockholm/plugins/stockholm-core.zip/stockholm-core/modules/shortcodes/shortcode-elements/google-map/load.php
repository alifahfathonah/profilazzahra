<?php

include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/google-map/functions.php';
include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/google-map/google-map.php';