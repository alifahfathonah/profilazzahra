<?php

require_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/content-slider/functions.php';
require_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/content-slider/content-slider.php';
require_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/content-slider/content-slide.php';