<?php

include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/centered-portfolio-carousel/functions.php';
include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/centered-portfolio-carousel/centered-portfolio-carousel.php';