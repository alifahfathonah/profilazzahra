<?php

include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/image-with-overlapping-info/functions.php';
include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/image-with-overlapping-info/image-with-overlapping-info.php';