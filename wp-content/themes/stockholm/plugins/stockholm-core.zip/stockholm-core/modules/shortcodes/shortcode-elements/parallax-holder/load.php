<?php

include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/parallax-holder/functions.php';
include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/parallax-holder/parallax-holder.php';
