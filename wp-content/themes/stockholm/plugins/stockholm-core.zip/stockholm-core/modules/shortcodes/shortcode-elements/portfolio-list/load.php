<?php

include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/portfolio-list/functions.php';
include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/portfolio-list/portfolio-list.php';