<?php

include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/simple-blog-list/functions.php';
include_once STOCKHOLM_CORE_SHORTCODES_ROOT_DIR.'/simple-blog-list/simple-blog-list.php';