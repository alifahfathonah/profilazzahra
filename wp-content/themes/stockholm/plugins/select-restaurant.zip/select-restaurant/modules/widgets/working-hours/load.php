<?php

include_once QODE_RESTAURANT_MODULES_ROOT_DIR . '/widgets/working-hours/functions.php';
include_once QODE_RESTAURANT_MODULES_ROOT_DIR . '/widgets/working-hours/working-hours.php';